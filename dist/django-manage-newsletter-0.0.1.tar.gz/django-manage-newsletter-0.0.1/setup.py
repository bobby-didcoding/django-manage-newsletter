from setuptools import setup

setup(
		package_data={'newsletter': ['templates/newsletter/*.html']},
	)